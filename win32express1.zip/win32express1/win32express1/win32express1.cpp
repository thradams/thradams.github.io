#include "stdafx.h"
#include "win32express1.h"

// Windows Header Files:
#include <windows.h>

// C RunTime Header Files
#include <stdlib.h>
#include <malloc.h>
#include <memory.h>
#include <tchar.h>

#include "win32express.h"
#include "resource.h"


class AboutDlg : public Dialog<AboutDlg, IDD_ABOUTBOX>
{
  void About()
  {  
  }

  void OnClose()
  {
    EndDialog(IDCANCEL);
  }

  void OnOk()
  {
    EndDialog(IDCANCEL);
    PostQuitMessage(1);
  }  

public:

  BEGIN_MSG_MAP(AboutDlg)
    S_COMMAND_ID_HANDLER(IDCANCEL, OnClose)  
    S_COMMAND_ID_HANDLER(IDOK, OnOk)  
    S_COMMAND_ID_HANDLER(IDM_ABOUT, About)
  END_MSG_MAP()

  AboutDlg(HWND hParent = NULL) : Dialog<AboutDlg, IDD_ABOUTBOX>(hParent) 
  {
  }

  void OnPaint(HDC hdc)
  {
   // ::TextOut(hdc, 10,10,L"hello", 6);
  }
};


class Doc : public Window<Doc, IDI_WIN32EXPRESS1, IDR_MAINFRAME>
{
  void Exit()
  {
    DestroyWindow(m_hWnd);
    PostQuitMessage(0);
  }

  void About()
  {
    AboutDlg dlg(m_hWnd);
    dlg.ShowDialog();
  }

public:

  BEGIN_MSG_MAP(AboutDlg)
    S_COMMAND_ID_HANDLER(IDM_ABOUT, About)
    S_COMMAND_ID_HANDLER(IDM_EXIT, Exit)
  END_MSG_MAP()

  int m_value;

  void OnMouseWheel(int fwKeys, short zDelta)
  {
  }
  void OnPaint(HDC hdc)
  {
    ::TextOut(hdc, 10,10,L"hello", 6);
  }
};

int APIENTRY _tWinMain(HINSTANCE hInstance,
                       HINSTANCE hPrevInstance,
                       LPTSTR    lpCmdLine,
                       int       nCmdShow)
{

  Doc doc;
  doc.Create();

  return RunMessageLoop();
}


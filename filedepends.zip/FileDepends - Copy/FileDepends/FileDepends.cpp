#include "stdafx.h"
#include <vector>
#include <string>

#include <iostream>
#include <set>
#include <iostream>
#include <fstream>


inline void find_replace(std::string& in_this_string,
                         const std::string& find,
                         const std::string& replace)
{
    std::string::size_type pos = 0;
    while ( std::string::npos != (pos = in_this_string.find(find, pos)) )
    {
        in_this_string.replace(pos, find.length(), replace);
        pos += replace.length();
    }
}

inline int cmp_nocase(const std::string& s, const std::string& s2)
{
    std::string::const_iterator p  = s.begin();
    std::string::const_iterator p2 = s2.begin();

    while (p != s.end() && p2 != s2.end())
    {
        if (toupper(*p) != toupper(*p2))
        {
            return (toupper(*p) < toupper(*p2)) ? -1 : 1;
        }
        ++p;
        ++p2;
    }
    return (s2.size()==s.size()) ? 0 : (s.size() < s2.size()) ? -1 : 1;
}

struct less
{
    bool operator ()(const std::string& s1,const std::string& s2) const
    {
        return cmp_nocase(s1, s2) < 0;
    }
};

typedef std::set<std::string, less> FilesSet;

int GetFileInfo(const char* filename,
                std::vector<std::string>& sourceh,
                FilesSet& includesh,
                std::vector<std::string>& sourcecpp,
                FilesSet& includescpp,
                FilesSet& done,
                bool includedincpp);

int GetFileInfo2(const char* filename, FilesSet& done, const std::vector<std::string>& includedir);

//bool IsStandard(const std::string& s);

bool FindDependencies(const char* filename, FilesSet& done);

std::string GetFullPath(const std::string& partialPath);
std::string GetCurrentPath();
std::string GetPath(const std::string& file);
std::string GetFileName(const std::string& file);
std::string SetCurrentPath(const std::string& path);

void print(const FilesSet& s,
           std::ostream& os,
           const char* begin)
{
    FilesSet::const_iterator it = s.begin();
    for ( ; it != s.end(); it++)
    {
        os <<  begin << *it <<  std::endl;
    }
}

void print(const std::vector<std::string>& s,
           std::ostream& os,
           const char* begin)
{
    std::vector<std::string>::const_iterator it = s.begin();
    for ( ; it != s.end(); it++)
    {
        os <<  begin << *it <<  std::endl;
    }
}

bool IsStandard(const std::string& s)
{
    static FilesSet se;
    if (se.empty())
    {
        std::ifstream file("stdincludes.txt");
        if (!file.is_open())
        {
            return false;
        }

        std::string str;
        while (std::getline(file, str))
        {
            se.insert(str);
        }
    }
    return se.find(s) != se.end();
}

bool IsCpp(const std::string& s)
{
    return s.find(".cpp") != std::string::npos;
}

bool IsHeader(const std::string& s)
{
    return s.find(".h") != std::string::npos;
}


#include <direct.h>

using namespace std;

std::string GetFullPath(const std::string& partialPath)
{
    std::string r;
    char full[_MAX_PATH];
    if ( _fullpath( full, partialPath.c_str(), _MAX_PATH ) != NULL )
    {
        r = full;
    }
    return r;
}

std::string GetCurrentPath()
{
    char* buffer;
    if ( (buffer = _getcwd( NULL, 0 )) == NULL )
    {
    }
    else
    {
        std::string s(buffer);
        free(buffer);
        return s;
    }
    return "";
}

std::string GetPath(const std::string& file)
{
    char drive[_MAX_DRIVE];
    char dir[_MAX_DIR];
    char fname[_MAX_FNAME];
    char ext[_MAX_EXT];

    _splitpath( file.c_str(), drive, dir, fname, ext ); // C4996

    std::string path(drive);
    path += dir;
    return path;
}

std::string GetFileName(const std::string& file)
{
    char drive[_MAX_DRIVE];
    char dir[_MAX_DIR];
    char fname[_MAX_FNAME];
    char ext[_MAX_EXT];

    _splitpath( file.c_str(), drive, dir, fname, ext ); // C4996

    std::string filename(fname);
    filename += ext;
    return filename;
}

std::string SetCurrentPath(const std::string& path)
{
    std::string old = GetCurrentPath();
    int er = _chdir(path.c_str());
    return old;
}



void RemoveAspas(std::string& s)
{
    //remove aspas
    if (s[0] == '"' ||
            s[0] == '<')
    {
        s = s.substr(1, s.size()-2);
    }
}

// 1 ja foi feito
// 2 nao achei <vector>
// 0 ok
int GetFileInfo(const char* filename,
                std::vector<std::string>& sourceh,
                FilesSet& includesh,
                std::vector<std::string>& sourcecpp,
                FilesSet& includescpp,
                FilesSet& done,
                bool includedincpp)
{

    std::string strfileName = filename;

    const bool iscpp = strfileName.find(".cpp") != std::string::npos;
    const bool isheader = strfileName.find(".h") != std::string::npos ;
    const bool issystem = !iscpp && !isheader;

    RemoveAspas(strfileName);

    if (done.find(strfileName) != done.end())
    {
        return 1;
    }

    done.insert(strfileName);

    cout << strfileName << endl;

    std::ifstream file(strfileName.c_str());

    if (!file.is_open())
    {
        // done.insert(strfileName);
        return 2;
    }



    std::string str;
    std::string strsource;
    while (std::getline(file, str))
    {
        int pos = str.find("#include");
        if (pos == 0 /*pos != std::string::npos*/)
        {
            int pos2 = pos + strlen("#include") + 1 ;
            std::string includefile = str.substr(pos2, str.size() - pos2);

            if (includefile != "\"stdafx.h\"")
            {

                std::string oldpath = SetCurrentPath(GetPath(strfileName));
                std::string includefilesemaspas = includefile;
                RemoveAspas(includefilesemaspas);
                std::string fullpath = GetFullPath(includefilesemaspas);

                int result = GetFileInfo(fullpath.c_str(), sourceh, includesh, sourcecpp, includescpp, done, includedincpp);
                SetCurrentPath(oldpath);

                if (isheader&& result == 2)
                {
                    includesh.insert(includefile);
                }
                else if (iscpp && result == 2)
                {

                    includescpp.insert(includefile);
                }

                else
                {
                }
            }
        }
        else
        {
            int pos = str.find("#pragma once");
            if (pos == std::string::npos)
            {
                strsource += str;
                strsource += "\n";
            }
        }
    }
    if (includedincpp)
    {
        sourcecpp.push_back(strsource);
    }
    else
    {
        sourceh.push_back(strsource);
    }
    if (isheader)
    {
        //vou processar o cpp se existir
        find_replace(strfileName, ".h", ".cpp");
        int r =  GetFileInfo(strfileName.c_str(), sourceh, includesh, sourcecpp, includescpp, done, true);
    }

    return 0; //ok
}

bool GetInclude(const std::string& line, std::string& s)
{
    int pos = line.find("#include");
    if (pos < 0)
    {
        return false;
    }

    pos = line.find("\"");
    if (pos > 0)
    {
        int begin = pos + 1;
        pos = line.find("\"", begin  );
        if (pos < 0)
        {
            return false;
        }
        s = line.substr(begin, pos-begin);
    }
    else
    {
        pos = line.find( "<");
        if (pos < 0)
        {
            return false;
        }

        int begin = pos + 1;
        pos = line.find( ">",begin);
        if (pos < 0)
        {
            return false;
        }

        s = line.substr(begin, pos-begin);
    }
    return true;
}


//int pos = str.find("#include");

// 1 ja foi feito
// 2 nao achei <vector>
// 0 ok
int GetFileInfo2(const char* filename,
                 FilesSet& done,
                 const std::vector<std::string>& includedir)
{

    std::string strfileName = filename;

    const bool iscpp = strfileName.find(".cpp") != std::string::npos;
    const bool isheader = strfileName.find(".h") != std::string::npos ;
    const bool issystem = !iscpp && !isheader;

    RemoveAspas(strfileName);

    if (done.find(strfileName) != done.end())
    {
        return 1;
    }

    if (done.find(GetFullPath(strfileName)) != done.end())
    {
        return 1;
    }



    std::ifstream file(strfileName.c_str());

    if (!file.is_open())
    {
        if (!iscpp)
        {
            done.insert(strfileName);
        }
        return 2;
    }


    done.insert(GetFullPath(strfileName));



    std::string str;
    while (std::getline(file, str))
    {

        std::string includefile;
        if (GetInclude(str, includefile))
        {
            std::string oldpath = SetCurrentPath(GetPath(strfileName));

            std::ifstream file(includefile.c_str());
            if (!file.is_open())
            {
                bool found = false;
                for (int k = 0; k < includedir.size(); k++)
                {

                    std::string fullpath = GetFullPath(includedir[k]);
                    SetCurrentPath(fullpath);


                    file.open(includefile.c_str());
                    if (file.is_open())
                    {
                        break;    //ok fical com este path
                    }

                    //tenta absoluto
                    fullpath = SetCurrentPath(includedir[k]);
                    file.open(includefile.c_str());
                    if (file.is_open())
                    {
                        break;    //ok fical com este path
                    }
                }
            }

            int result = GetFileInfo2(includefile.c_str(), done, includedir);
            SetCurrentPath(oldpath);
        }
    }

    if (isheader)
    {
        //vou processar o cpp se existir
        find_replace(strfileName, ".h", ".cpp");
        int r =  GetFileInfo2(strfileName.c_str(),  done, includedir);
    }

    return 0; //ok
}



int main(int argc, char* argv[])
{
    FilesSet done;

    if (argc < 2)
    {
        std::cout << " file.h or .cpp [adicional include file] [adicional include file] ...";
        return 1;
    }

    std::vector<std::string> includedir;
    for (int i = 2; i < argc; i++)
    {
        includedir.push_back(argv[i]);
    }

    std::string path = GetPath(argv[0]);
    SetCurrentPath(path);
    IsStandard("vector");
    GetFileInfo2(argv[1], done, includedir);


    std::cout << argv[1] <<  std::endl;

    {
        std::cout << "=== standard C++ headers ===" << std::endl;
        int count = 0;
        FilesSet::iterator it = done.begin();
        for ( ; it != done.end(); it++)
        {
            if (IsStandard(*it))
            {
                std::cout << *it << std::endl;
                count++;
            }
        }
        std::cout << "Total : " << count << std::endl;
        std::cout << std::endl;
    }

    {
        std::cout << "=== Header Files === " << std::endl;
        int count = 0;
        FilesSet::iterator it = done.begin();
        for ( ; it != done.end(); it++)
        {
            if (IsHeader(*it) && !IsStandard(*it))
            {
                std::cout << *it << "" << std::endl;
                count++;
            }
        }
        std::cout << "Total : " << count << std::endl;
        std::cout << std::endl;
    }

    {
        std::cout << "=== Implementation ===" << std::endl;
        int count = 0;
        FilesSet::iterator it = done.begin();
        for ( ; it != done.end(); it++)
        {
            if (IsCpp(*it))
            {
                std::cout << *it << "" << std::endl;
                count++;
            }
        }
        std::cout << "Total : " << count << std::endl;
        std::cout << std::endl;
    }


    return 0;
}


#include "stdafx.h"
#include "guiexpress\guiexpress.h"


int APIENTRY _tWinMain(HINSTANCE hInstance,
                       HINSTANCE hPrevInstance,
                       LPTSTR    lpCmdLine,
                       int       nCmdShow)
{
  GuiEx::Document doc;
  doc.Write(L"Hello world!");
  Run(doc);
}
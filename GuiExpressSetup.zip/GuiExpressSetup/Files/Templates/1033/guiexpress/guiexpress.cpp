
[!if SAMPLE_CHECKBOX]
#include "..\stdafx.h"
[!endif]

#include <windows.h>

#include "guiexpress.h"

#ifdef _WIN32_WCE
#include <ceconfig.h>
#if defined(WIN32_PLATFORM_PSPC) || defined(WIN32_PLATFORM_WFSP)
#define SHELL_AYGSHELL
#endif

#ifdef SHELL_AYGSHELL
#include <aygshell.h>
#pragma comment(lib, "aygshell.lib")
#endif // SHELL_AYGSHELL


static SHACTIVATEINFO s_sai;


#endif

#define WM_USER_ENDMODAL ((WM_USER) + 1)

HWND g_hWndMenuBar;     // menu bar handle



HMODULE hModule = 0;


typedef HDOCUMENT (*CreateDocumentPtr)();
typedef void (*DestroyDocumentPtr)(HDOCUMENT );
typedef HDOCUMENT (*SetWindowDocumentPtr)(HWND, HDOCUMENT);
typedef HDOCUMENT (*GetWindowDocumentPtr)(HWND);
typedef BOOL (*WritePtr)(HDOCUMENT, LPCWSTR);
typedef BOOL (*WriteElemPtr)(HELEMENT, LPCWSTR);
typedef BOOL (*ClearElemPtr)(HELEMENT);
typedef BOOL (*SetEventHandlerPtr)(HDOCUMENT, LPCWSTR, IGuiExEvent*);
typedef HELEMENT (*GetElementByIdPtr)(HDOCUMENT, LPCWSTR);

typedef int (*GetAttributePtr)(HELEMENT, LPCWSTR name, LPWSTR value, int nMaxCount);
typedef BOOL (*SetAttributePtr)(HELEMENT, LPCWSTR name, LPCWSTR value);

CreateDocumentPtr s_CreateDocument = 0;
DestroyDocumentPtr s_DestroyDocument = 0;
SetWindowDocumentPtr s_SetWindowDocument = 0;
GetWindowDocumentPtr s_GetWindowDocument = 0;
SetEventHandlerPtr s_SetEventHandler = 0;
GetElementByIdPtr s_GetElementById = 0;
WritePtr s_Write = 0;
SetAttributePtr s_SetAttribute = 0;
GetAttributePtr s_GetAttribute = 0;
WriteElemPtr s_WriteElem;
ClearElemPtr s_ClearElem;

void CheckLoadLibray()
{
    if (hModule == 0)
    {
        hModule = ::LoadLibraryW(L"GuiExpress");
        if (hModule)
        {
            s_CreateDocument = (CreateDocumentPtr) ::GetProcAddress(hModule, "GuiExCreateDocument");
            s_DestroyDocument = (DestroyDocumentPtr)::GetProcAddress(hModule, "GuiExDestroyDocument");
            s_GetWindowDocument = (GetWindowDocumentPtr) ::GetProcAddress(hModule, "GuiExGetWindowDocument");
            s_SetWindowDocument = (SetWindowDocumentPtr)::GetProcAddress(hModule, "GuiExSetWindowDocument");
            s_Write = (WritePtr)::GetProcAddress(hModule, "GuiExWrite");
            s_SetEventHandler = (SetEventHandlerPtr) ::GetProcAddress(hModule, "GuiExSetEventHandler");
            s_GetElementById = (GetElementByIdPtr) ::GetProcAddress(hModule, "GuiExGetElementById");
            s_GetAttribute = (GetAttributePtr) ::GetProcAddress(hModule, "GuiExGetAttribute");
            s_SetAttribute = (SetAttributePtr) ::GetProcAddress(hModule, "GuiExSetAttribute");
            s_WriteElem = (WriteElemPtr) ::GetProcAddress(hModule, "GuiExElemWrite");
            s_ClearElem = (ClearElemPtr) ::GetProcAddress(hModule, "GuiExClear");
        }
        else
        {
            DWORD dwError = GetLastError();
            if (dwError == ERROR_MOD_NOT_FOUND)
            {
                ::MessageBoxW(0, L"This application has failed to start because guiexpress.dll was not found. Re-installing the application may fix this problem.", L"GuiExpress", MB_ICONERROR);
            }
            else
            {
                ::MessageBoxW(0, L"This application has failed to start because an unexpected error loading guiexpress.dll. Re-installing the application may fix this problem.", L"GuiExpress", MB_ICONERROR);
            }
            exit(0);
        }
    }
}

HDOCUMENT GuiExCreateDocument()
{
    CheckLoadLibray();
    return s_CreateDocument();
}

BOOL GuiExWrite(HDOCUMENT h, LPCWSTR psz)
{
    CheckLoadLibray();
    return s_Write(h, psz);
}

void GuiExDestroyDocument(HDOCUMENT h)
{
    CheckLoadLibray();
    s_DestroyDocument(h);
}

HDOCUMENT GuiExSetWindowDocument(HWND h, HDOCUMENT hd)
{
    CheckLoadLibray();
    return s_SetWindowDocument(h, hd);
}

HDOCUMENT GuiExGetWindowDocument(HWND h)
{
    CheckLoadLibray();
    return s_GetWindowDocument(h);
}

BOOL GuiExSetEventHandler(HDOCUMENT hd, LPCWSTR psz, IGuiExEvent* e)
{
    CheckLoadLibray();
    return s_SetEventHandler(hd, psz, e);
}

HELEMENT GuiExGetElementById(HDOCUMENT h, LPCWSTR psz)
{
    CheckLoadLibray();
    return s_GetElementById(h, psz);
}

int GuiExGetAttribute(HELEMENT h, LPCWSTR name, LPWSTR value, int nMaxCount)
{
    return s_GetAttribute(h, name, value, nMaxCount);
}


BOOL GuiExSetAttribute(HELEMENT h, LPCWSTR name, LPCWSTR value)
{
    return s_SetAttribute(h, name, value);
}

BOOL GuiExElemWrite(HELEMENT h, LPCWSTR psz)
{
    CheckLoadLibray();
    return s_WriteElem(h, psz);
}

BOOL GuiExClear(HELEMENT h)
{
    CheckLoadLibray();
    return s_ClearElem(h);
}


////////




int RunMessageLoop()
{
    MSG msg;
    while (GetMessage(&msg, NULL, 0, 0))
    {
        if (msg.message == WM_USER_ENDMODAL)
            break;
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
    return (int) msg.wParam;
}

LRESULT CALLBACK WindowCreator::DefaultWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    return DefWindowProc(hWnd, message, wParam, lParam);
}

ATOM WindowCreator::MyRegisterClass(HINSTANCE hInstance)
{
#ifndef _WIN32_WCE
    WNDCLASSEX wcex;
    wcex.cbSize = sizeof(WNDCLASSEX);
    wcex.style          = CS_HREDRAW | CS_VREDRAW | CS_DBLCLKS;
    wcex.lpfnWndProc    = m_WndProc;
    wcex.cbClsExtra     = 0;
    wcex.cbWndExtra     = 0;
    wcex.hInstance      = hInstance;
    wcex.hIcon            = LoadIcon(hInstance, MAKEINTRESOURCE(m_IconId));
    wcex.hCursor          = LoadCursor(NULL, m_CursorId);
    wcex.hbrBackground  = (HBRUSH)(COLOR_WINDOW + 1);
    if (m_ResourceMenuId != NULL)
        wcex.lpszMenuName   = MAKEINTRESOURCE(m_ResourceMenuId);
    else
        wcex.lpszMenuName   = NULL;
    wcex.lpszClassName  = m_WindowClass.c_str();
    wcex.hIconSm        = 0;//LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));
    return RegisterClassEx(&wcex);
#else
    WNDCLASS wc;
    wc.style         = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc   = m_WndProc;
    wc.cbClsExtra    = 0;
    wc.cbWndExtra    = 0;
    wc.hInstance     = hInstance;
    wc.hIcon         = LoadIcon(hInstance, MAKEINTRESOURCE(m_IconId));
    wc.hCursor        = LoadCursor(NULL, m_CursorId);
    wc.hbrBackground = (HBRUSH) GetStockObject(WHITE_BRUSH);
#ifndef _WIN32_WCE
    if (m_ResourceMenuId != NULL)
        wc.lpszMenuName = MAKEINTRESOURCE(m_ResourceMenuId);
    else
        wc.lpszMenuName = NULL;
#else
    wc.lpszMenuName = NULL;
#endif
    wc.lpszClassName = m_WindowClass.c_str();
    return RegisterClass(&wc);
#endif
}

HWND WindowCreator::InitInstance(HINSTANCE hInstance, int nCmdShow)
{
    HWND hWnd;
    hWnd = CreateWindow(m_WindowClass.c_str(), m_Title.c_str(), m_Style,
                        m_x, m_y, m_Width, m_Height, m_hWndParent, NULL, hInstance, NULL);
    if (!hWnd)
    {
        return hWnd;
    }
    ShowWindow(hWnd, nCmdShow);
    UpdateWindow(hWnd);
    return hWnd;
}

WindowCreator::WindowCreator()
{
    m_WindowClass = L"GuiExpress";
    m_CursorId = IDC_ARROW;
    m_ResourceMenuId = NULL;
#ifndef _WIN32_WCE
    m_Style = WS_OVERLAPPEDWINDOW | CS_DBLCLKS;
#else
    m_Style = WS_VISIBLE;
#endif
    m_WndProc = &WindowCreator::DefaultWndProc;
    m_x = CW_USEDEFAULT;
    m_y = 0;
    m_Width = CW_USEDEFAULT;
    m_Height = 0;
    m_hWndParent = NULL;
}

HWND WindowCreator::Create()
{
    HINSTANCE hInstance = GetModuleHandle(NULL);
    MyRegisterClass(hInstance);
    HWND hWnd = InitInstance(hInstance, TRUE);
#ifdef WIN32_PLATFORM_PSPC
    // When the main window is created using CW_USEDEFAULT the height of the menubar (if one
    // is created is not taken into account). So we resize the window after creating it
    // if a menubar is present
    if (g_hWndMenuBar)
    {
        RECT rc;
        RECT rcMenuBar;
        GetWindowRect(hWnd, &rc);
        GetWindowRect(g_hWndMenuBar, &rcMenuBar);
        rc.bottom -= (rcMenuBar.bottom - rcMenuBar.top);
        MoveWindow(hWnd, rc.left, rc.top, rc.right - rc.left, rc.bottom - rc.top, FALSE);
    }
#endif // WIN32_PLATFORM_PSPC
#ifdef SHELL_AYGSHELL
    SHMENUBARINFO mbi;
    memset(&mbi, 0, sizeof(SHMENUBARINFO));
    mbi.cbSize     = sizeof(SHMENUBARINFO);
    mbi.hwndParent = hWnd;
    mbi.nToolBarId = m_ResourceMenuId;
    mbi.hInstRes   = hInstance;
    if (!SHCreateMenuBar(&mbi))
    {
        g_hWndMenuBar = NULL;
    }
    else
    {
        g_hWndMenuBar = mbi.hwndMB;
    }
    // Initialize the shell activate info structure
    memset(&s_sai, 0, sizeof (s_sai));
    s_sai.cbSize = sizeof (s_sai);
#endif // SHELL_AYGSHELL
    return hWnd;
}

void WindowCreator::SetResourceMenu(UINT MenuId)
{
    m_ResourceMenuId = MenuId;
}

void WindowCreator::SetWndProc(WNDPROC p)
{
    m_WndProc = p;
}

UINT WindowCreator::GetResourceMenu() const
{
    return m_ResourceMenuId;
}

void WindowCreator::SetTitle(const std::wstring& s)
{
    m_Title = s;
}

const std::wstring& WindowCreator::GetTitle() const
{
    return m_Title;
}

namespace GuiEx
{

    /*
    int DoModal(HWND hWnd, Document& doc)
    {
    HWND hWndOld = doc.m_hWnd; //no caso de ser o mesmo doc em hwnd diferentes

    //TODO caso for a mesma janela  e mesmo doc

    HDOCUMENT *pDoc = GuiExSetWindowDocument(hWnd, doc.m_hDoc );

    int r = RunMessageLoop();
    GuiExSetWindowDocument(hWnd, pDoc);

    doc.m_hWnd = hWndOld;
    return r;
    }
    */
    int Run(GuiEx::Document& doc)
    {
        WindowCreator creator;
        HWND hWnd = creator.Create();
        GuiExSetWindowDocument(hWnd, doc.m_hDoc);
        return RunMessageLoop();
    }
}



#pragma once

#include <windows.h>
#include <functional>

#define GUIEX_DECLARE_HANDLE(name) struct name##__ { int unused; }; typedef struct name##__ *name

GUIEX_DECLARE_HANDLE(HDOCUMENT);
GUIEX_DECLARE_HANDLE(HELEMENT);


//DLL C API ////////////////////////////////////////////////////
struct IGuiExEvent
{
    virtual void OnEvent(HELEMENT) = 0;
    virtual void AddRef() = 0;
    virtual int Release() = 0;
};


HDOCUMENT GuiExCreateDocument();
void GuiExDestroyDocument(HDOCUMENT);
HELEMENT GuiExGetElementById(HDOCUMENT h, LPCWSTR psz);
BOOL GuiExSetEventHandler(HDOCUMENT, LPCWSTR, IGuiExEvent *);
BOOL GuiExWrite(HDOCUMENT, LPCWSTR);

BOOL GuiExElemWrite(HELEMENT, LPCWSTR);
BOOL GuiExClear(HELEMENT);
int GuiExGetAttribute(HELEMENT, LPCWSTR name, LPWSTR value, int nMaxCount);
BOOL GuiExSetAttribute(HELEMENT, LPCWSTR name, LPCWSTR value);


HDOCUMENT GuiExSetWindowDocument(HWND, HDOCUMENT);
HDOCUMENT GuiExGetWindowDocument(HWND);

//DLL C API ////////////////////////////////////////////////////

//Windows helpers

int RunMessageLoop();

class WindowCreator
{
    std::wstring m_Title;
    std::wstring m_WindowClass;

    WNDPROC m_WndProc;
    UINT m_IconId;
    LPCWSTR m_CursorId;
    UINT m_ResourceMenuId;
    UINT m_Style;
    HWND m_hWndParent;

    int m_x;
    int m_y;
    int m_Width;
    int m_Height;

    static LRESULT CALLBACK DefaultWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
    ATOM MyRegisterClass(HINSTANCE hInstance);
    HWND InitInstance(HINSTANCE hInstance, int nCmdShow);

    
public:
    WindowCreator();

    HWND Create();
    void SetResourceMenu(UINT MenuId);
    void SetWndProc(WNDPROC);
    UINT GetResourceMenu() const;
    void SetTitle(const std::wstring&);
    const std::wstring& GetTitle() const;
};


//C++ Wrappers

class EventHandler : public IGuiExEvent 
{
    std::tr1::function<void (HELEMENT)> m_ev;
    int count;
public:
    template<class T>
    EventHandler(const T &f) : m_ev(f)
    {
        count = 1;
        m_ev = f;
    }
    virtual void OnEvent(HELEMENT h)
    {
        if (m_ev)
            m_ev(h);
    }

    virtual void AddRef() 
    {
        count++;
    }

    virtual int Release() 
    {
        count--;
        if (count == 0)
            delete this;
        return count;
    }
};



namespace GuiEx
{
    class Element
    {
    public:
        HELEMENT m_hElem;

        Element(HELEMENT h = 0) : m_hElem(h)
        {
        }


        ~Element()
        {
        }

        Element(const Element& other) : m_hElem(other.m_hElem)
        {
        }

        Element & operator =(HELEMENT h)
        {
            m_hElem = h;
            return *this;
        }

        void Write(const wchar_t* psz)
        {
           GuiExElemWrite(m_hElem, psz);
        }

        void Clear()
        {
            GuiExClear(m_hElem);
        }

        std::wstring GetAttribute(const std::wstring& name)
        {
           wchar_t v[1000];
           int c = GuiExGetAttribute(m_hElem, name.c_str(), v, 100);
           v[c] = 0;
           return v;
        }

        void SetAttribute(const std::wstring& name, const std::wstring& value)
        {
           GuiExSetAttribute(m_hElem, name.c_str(), value.c_str());
        }
    };
  
    class Document
    {
        std::wstring MakeCommandName(unsigned int id)
        {
            wchar_t dest[20];
            _itow(id, dest, 10);
            std::wstring name(L"cmd");
            name += dest;
            return name;
        }

    public:
        HDOCUMENT m_hDoc;

        template<class T>
        void Event(const std::wstring& name, void (T::*f)(HELEMENT))
        {    
            GuiExSetEventHandler(m_hDoc, name.c_str(), new EventHandler(std::tr1::bind(f, static_cast<T*>(this), std::tr1::placeholders::_1)));
        }

        template<class T>
        void CommandEvent(unsigned int id, void (T::*f)(HELEMENT))
        {            
            GuiExSetEventHandler(m_hDoc, MakeCommandName(id).c_str(), new EventHandler(std::tr1::bind(f, static_cast<T*>(this), std::tr1::placeholders::_1)));
        }


        Document()
        {
            m_hDoc = GuiExCreateDocument();
        }

        ~Document()
        {
            GuiExDestroyDocument(m_hDoc);
        }

        Element GetElementById(const std::wstring& s)
        {
            return GuiExGetElementById(m_hDoc, s.c_str());
        }

        void Clear()
        {
          GuiExClear((HELEMENT)m_hDoc);
        }

        void Write(const wchar_t* psz)
        {
            GuiExWrite(m_hDoc, psz);
        }
    };
    

    int Run(GuiEx::Document& doc);
}

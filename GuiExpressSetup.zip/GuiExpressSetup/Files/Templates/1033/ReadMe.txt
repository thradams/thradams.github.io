========================================================================
    GuiExpressWiz : [!output PROJECT_NAME] Project Overview
========================================================================

GuiExpressWiz has created this [!output PROJECT_NAME] project for you as a starting point.

This file contains a summary of what you will find in each of the files that make up your project.

GuiExpressWiz.vcproj
    This is the main project file for projects generated using an Application Wizard. 
    It contains information about the version of the product that generated the file, and 
    information about the platforms, configurations, and project features selected with the
    Application Wizard.

Sample.txt
This is a sample template file.

/////////////////////////////////////////////////////////////////////////////
Other notes:

/////////////////////////////////////////////////////////////////////////////

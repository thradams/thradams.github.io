#include "stdafx.h"
#include "unittest.h"
using namespace UnitTest;

[!if SAMPLE_CHECKBOX]
void TestOne()
{
    int a = 2;
    int b = 2;
    AreEqual(a, b);
    IsTrue(a + b == 4);    
}
TEST_ENTRY(TestOne)
[!endif]

[!if SAMPLE_CHECKBOX0]
class group1
{
public:
    group1()
    {
    }
    ~group1()
    {
    }
};

void Test1Group1(group1&)
{
}
TEST_ENTRY(Test1Group1)

void Test2Group1(group1&)
{
}
TEST_ENTRY(Test2Group1)

[!endif]


int main()
{
    ConsoleReport rep;
    RunAll(rep);
    return rep.GetFailedCount();
}

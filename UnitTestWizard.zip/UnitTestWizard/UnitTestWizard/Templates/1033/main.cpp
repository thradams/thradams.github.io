#include "stdafx.h"
#include "unittest.h"
using namespace UnitTest;

[!if SAMPLE_CHECKBOX]
TEST_FUNCTION(TestOne)()
{
    int a = 2;
    int b = 2;
    AreEqual(a, b);
    IsTrue(a + b == 4);
}

[!endif]

[!if SAMPLE_CHECKBOX0]

class Group1
{
  int a;
  int b;

public:
    Group1()
    {
      a = 1;
      b = 1;
    }
    ~Group1()
    {
    }
    
    void Test1()
    {
      AreEqual(a, b);
    }

    void Test2()
    {
      IsTrue_(a + b == 4);
    }
};
GROUP_TEST_ENTRY(Test1, Group1);
GROUP_TEST_ENTRY(Test2, Group1);

[!endif]


int main()
{
    ConsoleReport rep;
    RunAll(rep);
    return rep.GetFailedCount();
}
